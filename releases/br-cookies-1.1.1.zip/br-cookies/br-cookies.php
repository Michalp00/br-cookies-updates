<?php
/**
 * Plugin Name: BR Cookies
 * Description: Baner zgód na cookies z panelem ustawień, Google Consent Mode v2 i blokadą map oraz filmów do czasu zgody.
 * Version: 1.1.1
 * Update URI: https://michalp00.github.io/br-cookies-updates/
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Author: BrandRocks
 * Author URI: https://brandrocks.pl
 * License: GPL-2.0-or-later
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'BR_COOKIES_VERSION', '1.1.1' );
define( 'BR_COOKIES_FILE', __FILE__ );
define( 'BR_COOKIES_DIR', __DIR__ );

// Adres i klucz publiczny aktualizacji. Można je nadpisać w wp-config.php, a pusty adres wyłącza aktualizacje.
if ( ! defined( 'BR_COOKIES_UPDATE_URL' ) ) {
	define( 'BR_COOKIES_UPDATE_URL', 'https://michalp00.github.io/br-cookies-updates/manifest.json' );
}
if ( ! defined( 'BR_COOKIES_UPDATE_PUBLIC_KEY' ) ) {
	define( 'BR_COOKIES_UPDATE_PUBLIC_KEY', 'QBrjE8md7Ho9sNyiwAaykNA5nVzaA3rLUoveyr9a3n8=' );
}

require_once __DIR__ . '/includes/settings.php';
require_once __DIR__ . '/includes/log.php';
require_once __DIR__ . '/includes/frontend.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/updater.php';

add_action( 'plugins_loaded', function () {
	// Stara wtyczka z Jet Boat pokazałaby drugi baner.
	$conflict = defined( 'JB_CC_VERSION' );

	if ( is_admin() ) {
		BR_Cookies_Admin::init( $conflict );
	} elseif ( ! $conflict ) {
		BR_Cookies_Frontend::init();
	}
	if ( ! $conflict ) {
		BR_Cookies_Log::init();
	}
	BR_Cookies_Updater::init();
} );

register_deactivation_hook( __FILE__, array( 'BR_Cookies_Log', 'deactivate' ) );
