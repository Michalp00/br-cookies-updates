(function () {
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  var form = $('#br-form');
  var stage = $('#br-stage');
  var demo = $('#br-demo');
  var icon = $('#br-demo-icon');
  var state = { device: 'desktop', done: false };

  function val(name) {
    var el = $('[name="br_cookies_settings[' + name + ']"]:checked') || $('[name="br_cookies_settings[' + name + ']"]');
    return el ? el.value : '';
  }

  function color(key) { return $('[data-color="' + key + '"]').value; }

  function currentLang() { return $('#br-language').value; }

  function text(key) {
    var el = $('.br-lang[data-lang="' + currentLang() + '"] [data-text="' + key + '"]');
    return el ? el.value : '';
  }

  function showTab(id) {
    $$('.br-tab').forEach(function (t) { t.setAttribute('aria-selected', t.dataset.tab === id ? 'true' : 'false'); });
    $$('.br-panel').forEach(function (p) { p.hidden = p.dataset.panel !== id; });
    $('[data-save]').hidden = id === 'tools';
    var ref = $('[name="_wp_http_referer"]', form);
    if (ref) {
      var u = new URL(ref.value, location.href);
      u.searchParams.set('tab', id);
      ref.value = u.pathname + u.search;
    }
  }

  function render() {
    var bar = val('layout') === 'bar';
    var phone = state.device === 'phone';
    var radius = Number(val('radius'));
    $('#br-radius-out').textContent = radius;
    $('#br-position').hidden = bar;
    $('#br-reject-warning').hidden = $('#br-show-reject').checked;

    $$('.br-lang').forEach(function (l) { l.hidden = l.dataset.lang !== currentLang(); });
    $$('.br-color-input').forEach(function (c) { $('code', c).textContent = $('input', c).value; });

    stage.classList.toggle('is-phone', phone);
    demo.className = 'br-demo ' + (phone ? 'is-phone' : bar ? 'is-bar' : 'is-box is-' + val('position'));
    demo.hidden = state.done;
    demo.style.background = color('bg');
    demo.style.color = color('fg');
    demo.style.borderRadius = bar && !phone ? '0' : radius + 'px';

    $('#br-demo-title').textContent = text('title');
    $('#br-demo-desc').textContent = text('desc');

    var buttons = { accept: ['accent', 'accent_fg'], reject: ['accent', 'accent_fg'], settings: ['second', 'second_fg'] };
    Object.keys(buttons).forEach(function (key) {
      var b = $('#br-demo-' + key);
      b.textContent = text(key);
      b.style.background = color(buttons[key][0]);
      b.style.color = color(buttons[key][1]);
      b.style.borderRadius = Math.round(radius / 2) + 'px';
    });
    $('#br-demo-reject').hidden = !$('#br-show-reject').checked;

    icon.hidden = !state.done || !$('#br-show-icon').checked;
    icon.style.background = color('icon_bg');
    icon.style.color = color('accent_fg');

    $('#br-preview-done').textContent = state.done ? 'Pokaż baner' : 'Pokaż po decyzji';
    $$('[data-device]').forEach(function (b) { b.setAttribute('aria-pressed', b.dataset.device === state.device ? 'true' : 'false'); });
  }

  var presets = {
    ga: { name: 'Google Analytics', category: 'analytics', cookies: '_ga, _ga_*', purpose: 'Statystyki odwiedzin strony', lifetime: 'do 2 lat', url: 'https://policies.google.com/privacy' },
    ads: { name: 'Google Ads', category: 'marketing', cookies: '_gcl_au', purpose: 'Pomiar konwersji i remarketing', lifetime: '3 miesiące', url: 'https://policies.google.com/privacy' },
    meta: { name: 'Meta', category: 'marketing', cookies: '_fbp, _fbc', purpose: 'Pomiar i dopasowanie reklam', lifetime: '3 miesiące', url: 'https://www.facebook.com/privacy/policy' },
    maps: { name: 'Mapy Google', category: 'media', cookies: 'cookies dostawcy', purpose: 'Wyświetlanie mapy dojazdu', lifetime: 'według dostawcy', url: 'https://policies.google.com/privacy' },
    youtube: { name: 'YouTube', category: 'media', cookies: 'cookies dostawcy', purpose: 'Odtwarzanie filmów', lifetime: 'według dostawcy', url: 'https://policies.google.com/privacy' }
  };
  var providers = $('#br-providers');
  var nextProvider = $$('[data-provider]', providers).length;

  function addProvider(values) {
    var html = $('#br-provider-template').innerHTML.replace(/__i__/g, String(nextProvider++));
    var box = document.createElement('div');
    box.innerHTML = html;
    var row = box.firstElementChild;
    Object.keys(values || {}).forEach(function (key) {
      var el = $('[data-field="' + key + '"]', row);
      if (el) el.value = values[key];
    });
    providers.appendChild(row);
    $('[data-field="name"]', row).focus();
  }

  $$('[data-preset]').forEach(function (b) {
    b.addEventListener('click', function () { addProvider(presets[b.dataset.preset]); });
  });
  providers.addEventListener('click', function (e) {
    var remove = e.target.closest('[data-remove]');
    if (remove) remove.closest('[data-provider]').remove();
  });

  $$('.br-tab').forEach(function (t) { t.addEventListener('click', function () { showTab(t.dataset.tab); }); });
  form.addEventListener('input', render);
  form.addEventListener('change', render);
  $$('[data-device]').forEach(function (b) {
    b.addEventListener('click', function () { state.device = b.dataset.device; render(); });
  });
  $('#br-preview-done').addEventListener('click', function () { state.done = !state.done; render(); });
  $('#br-reset').addEventListener('submit', function (e) {
    if (!window.confirm('Baner wróci u wszystkich użytkowników. Kontynuować?')) e.preventDefault();
  });

  var active = $('.br-tab[aria-selected="true"]');
  showTab(active ? active.dataset.tab : 'look');
  render();
})();
