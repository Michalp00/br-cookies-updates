window.dataLayer=window.dataLayer||[];window.gtag=window.gtag||function(){dataLayer.push(arguments);};
(function(){
  var kat=[];
  try{
    var m=document.cookie.match(/(?:^|;\s*)cc_cookie=([^;]+)/);
    if(m){
      var c=JSON.parse(decodeURIComponent(m[1]));
      if(c.revision===window.BRCookiesBoot.revision)kat=c.categories||[];
    }
  }catch(e){}
  var s=function(k){return kat.indexOf(k)>-1?'granted':'denied';};
  gtag('consent','default',{
    analytics_storage:s('analytics'),
    ad_storage:s('marketing'),
    ad_user_data:s('marketing'),
    ad_personalization:s('marketing'),
    personalization_storage:s('marketing'),
    functionality_storage:'granted',
    security_storage:'granted',
    wait_for_update:500
  });
})();
