(function () {
  var CC = window.CookieConsent;
  var cfg = window.BRCookies;
  if (!CC || !cfg) return;

  var accepted = function (id) { return CC.acceptedCategory(id); };

  function updateGoogle() {
    if (cfg.gcm) {
      var s = function (id) { return accepted(id) ? 'granted' : 'denied'; };
      window.gtag('consent', 'update', {
        analytics_storage: s('analytics'),
        ad_storage: s('marketing'),
        ad_user_data: s('marketing'),
        ad_personalization: s('marketing'),
        personalization_storage: s('marketing')
      });
    }
    if (cfg.gtmEvent) {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: 'br_consent_update',
        br_consent_analytics: accepted('analytics'),
        br_consent_marketing: accepted('marketing'),
        br_consent_media: accepted('media')
      });
    }
  }

  var pixelStarted = false;

  // Standardowy kod Mety, uruchamiany dopiero po zgodzie na reklamy.
  function loadPixelScript() {
    if (window.fbq) return;
    var n = window.fbq = function () {
      n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
    };
    if (!window._fbq) window._fbq = n;
    n.push = n;
    n.loaded = true;
    n.version = '2.0';
    n.queue = [];
    var s = document.createElement('script');
    s.async = true;
    s.src = 'https://connect.facebook.net/en_US/fbevents.js';
    var first = document.getElementsByTagName('script')[0];
    first.parentNode.insertBefore(s, first);
  }

  function syncPixel() {
    if (!cfg.metaPixel) return;
    if (accepted('marketing')) {
      if (pixelStarted) { window.fbq('consent', 'grant'); return; }
      pixelStarted = true;
      loadPixelScript();
      window.fbq('init', cfg.metaPixel);
      window.fbq('track', 'PageView');
    } else if (pixelStarted) {
      window.fbq('consent', 'revoke');
    }
  }

  function loadFrame(frame) {
    var src = frame.getAttribute('data-br-src');
    if (!src) return;
    var box = frame.previousElementSibling;
    if (box && box.classList.contains('br-cc-placeholder')) box.remove();
    frame.setAttribute('src', src);
    frame.removeAttribute('data-br-src');
    frame.style.display = '';
  }

  function refreshFrames() {
    document.querySelectorAll('iframe[data-br-src]').forEach(function (frame) {
      if (accepted('media')) { loadFrame(frame); return; }

      var prev = frame.previousElementSibling;
      if (prev && prev.classList.contains('br-cc-placeholder')) return;

      var isMap = frame.getAttribute('data-br-kind') === 'map';
      var box = document.createElement('div');
      box.className = 'br-cc-placeholder';
      var info = document.createElement('p');
      info.textContent = decode(isMap ? cfg.fixed.map_info : cfg.fixed.video_info);
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = decode(isMap ? cfg.fixed.show_map : cfg.fixed.show_video);
      btn.addEventListener('click', function () { loadFrame(frame); });
      box.appendChild(info);
      box.appendChild(btn);
      frame.style.display = 'none';
      frame.parentNode.insertBefore(box, frame);
    });
  }

  // Napisy przychodzą zakodowane pod HTML, a textContent pokazałby encje dosłownie.
  function decode(text) {
    var el = document.createElement('textarea');
    el.innerHTML = text;
    return el.value;
  }

  function showIcon() {
    if (!cfg.showIcon || document.querySelector('.br-cc-icon')) return;
    var btn = document.createElement('button');
    var label = decode(cfg.fixed.cookies_label);
    btn.type = 'button';
    btn.className = 'br-cc-icon';
    btn.title = label;
    btn.setAttribute('aria-label', label);
    btn.innerHTML = '<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" fill="currentColor"><path d="M21.6 11.2a4 4 0 0 1-4.3-3.5 4 4 0 0 1-4.9-4.9A9.5 9.5 0 1 0 21.6 11.2zM8 9.5A1.5 1.5 0 1 1 8 12.5 1.5 1.5 0 0 1 8 9.5zm1 6a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm6 .5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm-2.5-4a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/></svg>';
    btn.addEventListener('click', function () { CC.showPreferences(); });
    document.body.appendChild(btn);
  }

  // Bez ikony ustawienia muszą dać się otworzyć ze stopki, obok linku do polityki.
  function addFooterLink() {
    if (!cfg.policyUrl) return;
    var path = cfg.policyUrl.replace(/^https?:\/\/[^/]+/i, '').replace(/&#0?38;|&amp;/g, '&');
    if (!path || path === '/') return;
    document.querySelectorAll('footer a[href]').forEach(function (a) {
      if (a.getAttribute('href').indexOf(path) === -1) return;
      var holder = a.closest('.elementor-widget') || a.parentNode;
      if (holder.parentNode.querySelector('.br-cc-link')) return;
      var link = document.createElement('button');
      link.type = 'button';
      link.className = 'br-cc-link';
      link.setAttribute('data-cc', 'show-preferencesModal');
      link.textContent = decode(cfg.fixed.cookies_label);
      link.style.setProperty('color', getComputedStyle(a).color, 'important');
      holder.parentNode.insertBefore(link, holder.nextSibling);
    });
  }

  function cookieMatcher(name) {
    if (name.indexOf('*') === -1) return { name: name };
    var body = name.split('*').map(function (part) {
      return part.replace(/[.\-]/g, '\\$&');
    }).join('.*');
    return { name: new RegExp('^' + body + '$') };
  }

  function logConsent(event) {
    if (!cfg.logUrl || !window.fetch) return;
    fetch(cfg.logUrl, {
      method: 'POST',
      credentials: 'omit',
      keepalive: true,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        consent_id: CC.getCookie('consentId'),
        categories: CC.getUserPreferences().acceptedCategories,
        event: event
      })
    }).catch(function () {});
  }

  // Identyfikator pozwala znaleźć wpis w rejestrze, gdy użytkownik o niego zapyta.
  function showConsentId() {
    var id = CC.validConsent() && CC.getCookie('consentId');
    var body = document.querySelector('#cc-main .pm__body');
    if (!id || !body || !cfg.logUrl) return;
    var el = body.querySelector('.br-cc-id');
    if (!el) {
      el = document.createElement('p');
      el.className = 'br-cc-id';
      body.appendChild(el);
    }
    el.textContent = decode(cfg.fixed.consent_id) + ': ' + id;
  }

  function afterChange() { updateGoogle(); syncPixel(); refreshFrames(); showIcon(); }

  function cookieTable(rows) {
    return {
      headers: {
        provider: cfg.fixed.col_provider,
        cookies: cfg.fixed.col_cookies,
        purpose: cfg.fixed.col_purpose,
        lifetime: cfg.fixed.col_lifetime
      },
      body: rows
    };
  }

  var categories = { necessary: { enabled: true, readOnly: true } };
  var sections = [
    {
      title: cfg.fixed.necessary_name,
      description: cfg.fixed.necessary_desc + (cfg.logUrl ? ' ' + cfg.fixed.record_info : ''),
      linkedCategory: 'necessary',
      cookieTable: cookieTable(cfg.ownRows)
    }
  ];
  cfg.categories.forEach(function (cat) {
    categories[cat.id] = cat.cookies.length ? { autoClear: { cookies: cat.cookies.map(cookieMatcher) } } : {};
    var section = { title: cat.name, description: cat.desc, linkedCategory: cat.id };
    if (cat.rows.length) section.cookieTable = cookieTable(cat.rows);
    sections.push(section);
  });
  var policyLink = cfg.policyUrl ? '<a href="' + cfg.policyUrl + '">' + cfg.fixed.policy + '</a>' : '';
  if (policyLink) sections.push({ title: cfg.fixed.more_title, description: policyLink });

  var consentModal = {
    title: cfg.texts.title,
    description: cfg.texts.desc,
    acceptAllBtn: cfg.texts.accept,
    showPreferencesBtn: cfg.texts.settings,
    footer: policyLink
  };
  // Bez tego klucza CookieConsent nie rysuje przycisku. W oknie ustawień zostaje zawsze.
  if (cfg.showReject) consentModal.acceptNecessaryBtn = cfg.texts.reject;

  var isBar = cfg.layout === 'bar';
  var translations = {};
  translations[cfg.lang] = {
    consentModal: consentModal,
    preferencesModal: {
      title: cfg.fixed.prefs_title,
      acceptAllBtn: cfg.texts.accept,
      acceptNecessaryBtn: cfg.texts.reject,
      savePreferencesBtn: cfg.fixed.save,
      closeIconLabel: cfg.fixed.close,
      sections: sections
    }
  };

  addFooterLink();

  // Przy pierwszej wizycie onConsent nie startuje, a ramka bez adresu byłaby pusta.
  CC.run({
    revision: cfg.revision,
    guiOptions: {
      consentModal: {
        layout: isBar ? 'bar' : 'box',
        position: isBar ? 'bottom' : 'bottom ' + cfg.position,
        equalWeightButtons: true,
        flipButtons: false
      },
      preferencesModal: { layout: 'box', equalWeightButtons: true, flipButtons: false }
    },
    cookie: { expiresAfterDays: 182, sameSite: 'Lax' },
    onConsent: afterChange,
    onFirstConsent: function () { logConsent('first'); },
    onChange: function () { afterChange(); logConsent('change'); },
    onModalShow: function (e) { if (e.modalName === 'preferencesModal') showConsentId(); },
    categories: categories,
    language: { default: cfg.lang, translations: translations }
  }).then(refreshFrames);
})();
