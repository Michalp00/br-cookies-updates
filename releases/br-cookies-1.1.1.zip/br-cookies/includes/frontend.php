<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BR_Cookies_Frontend {

	public static function init() {
		add_action( 'wp_head', array( __CLASS__, 'print_consent_default' ), PHP_INT_MIN );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'template_redirect', array( __CLASS__, 'start_blocker' ) );
		add_shortcode( 'br_cookies_settings', array( __CLASS__, 'shortcode' ) );
	}

	private static function in_builder() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- tylko odczyt trybu podglądu.
		return isset( $_GET['elementor-preview'] ) || is_customize_preview();
	}

	// Domyślny stan zgód musi trafić do dataLayer przed kontenerem GTM.
	public static function print_consent_default() {
		$s = BR_Cookies_Settings::get();
		if ( ! $s['gcm'] || self::in_builder() ) {
			return;
		}
		$boot = wp_json_encode( array( 'revision' => (int) $s['revision'] ) );
		$js   = file_get_contents( BR_COOKIES_DIR . '/assets/consent-default.js' );
		echo '<script data-no-optimize="1" data-no-defer="1" data-cfasync="false" data-pagespeed-no-defer>window.BRCookiesBoot=' . $boot . ';' . $js . "</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- stały plik i JSON z liczbą.
	}

	public static function enqueue() {
		if ( self::in_builder() ) {
			return;
		}
		$url = plugin_dir_url( BR_COOKIES_FILE ) . 'assets/';
		wp_enqueue_style( 'br-cookies-vendor', $url . 'vendor/cookieconsent.css', array(), '3.1.0' );
		wp_enqueue_style( 'br-cookies', $url . 'br-cookies.css', array( 'br-cookies-vendor' ), BR_COOKIES_VERSION );
		wp_add_inline_style( 'br-cookies', self::css_vars() );

		wp_enqueue_script( 'br-cookies-vendor', $url . 'vendor/cookieconsent.umd.js', array(), '3.1.0', true );
		wp_enqueue_script( 'br-cookies', $url . 'br-cookies.js', array( 'br-cookies-vendor' ), BR_COOKIES_VERSION, true );
		wp_add_inline_script( 'br-cookies', 'window.BRCookies=' . wp_json_encode( self::config(), JSON_HEX_TAG | JSON_HEX_AMP ) . ';', 'before' );
	}

	private static function css_vars() {
		$s = BR_Cookies_Settings::get();
		$c = $s['colors'];
		$r = (int) $s['radius'];

		// Wartości pochodzą z sanitize_hex_color, a przy starych danych wracają do domyślnych.
		foreach ( $c as $key => $value ) {
			$c[ $key ] = sanitize_hex_color( $value ) ?: BR_Cookies_Settings::defaults()['colors'][ $key ];
		}

		return "#cc-main{--cc-bg:{$c['bg']};--cc-primary-color:{$c['fg']};--cc-secondary-color:{$c['fg']};"
			. "--cc-btn-primary-bg:{$c['accent']};--cc-btn-primary-color:{$c['accent_fg']};--cc-btn-primary-border-color:{$c['accent']};"
			. "--cc-btn-primary-hover-bg:{$c['accent']};--cc-btn-primary-hover-color:{$c['accent_fg']};--cc-btn-primary-hover-border-color:{$c['accent']};"
			. "--cc-btn-secondary-bg:{$c['second']};--cc-btn-secondary-color:{$c['second_fg']};--cc-btn-secondary-border-color:{$c['second']};"
			. "--cc-btn-secondary-hover-bg:{$c['second']};--cc-btn-secondary-hover-color:{$c['second_fg']};--cc-btn-secondary-hover-border-color:{$c['second']};"
			. "--cc-toggle-on-bg:{$c['accent']};--cc-link-color:{$c['fg']};--cc-footer-bg:{$c['bg']};--cc-footer-color:{$c['fg']};"
			. "--cc-modal-border-radius:{$r}px;--cc-btn-border-radius:" . round( $r / 2 ) . 'px}'
			. ".br-cc-icon{background:{$c['icon_bg']}!important;color:{$c['accent_fg']}!important}"
			. ".br-cc-placeholder button{background:{$c['accent']}!important;color:{$c['accent_fg']}!important}";
	}

	// Treści są wyświetlane przez CookieConsent jako HTML, dlatego wychodzą stąd zawsze zakodowane.
	private static function config() {
		$s    = BR_Cookies_Settings::get();
		$lang = $s['language'];
		$t    = array_map( 'esc_html', $s['texts'][ $lang ] );
		$f    = array_map( 'esc_html', BR_Cookies_Settings::fixed_texts( $lang ) );

		$categories = array();
		foreach ( BR_Cookies_Settings::CATEGORIES as $cat ) {
			if ( ! $s['categories'][ $cat ]['enabled'] ) {
				continue;
			}
			$categories[] = array(
				'id'      => $cat,
				'name'    => $t[ $cat . '_name' ],
				'desc'    => $t[ $cat . '_desc' ],
				'cookies' => array_values( array_filter( array_map( 'trim', explode( ',', $s['categories'][ $cat ]['cookies'] ) ) ) ),
				'rows'    => self::provider_rows( $s['providers'], $cat ),
			);
		}

		return array(
			'lang'       => $lang,
			'layout'     => $s['layout'],
			'position'   => $s['position'],
			'showReject' => (bool) $s['show_reject'],
			'showIcon'   => (bool) $s['show_icon'],
			'gcm'        => (bool) $s['gcm'],
			'gtmEvent'   => (bool) $s['gtm_event'],
			'metaPixel'  => $s['categories']['marketing']['enabled'] && preg_match( '/^\d{5,20}$/', (string) $s['meta_pixel_id'] ) ? (string) $s['meta_pixel_id'] : '',
			'revision'   => (int) $s['revision'],
			'policyUrl'  => esc_url( $s['policy_url'], array( 'http', 'https' ) ),
			'texts'      => $t,
			'fixed'      => $f,
			'categories' => $categories,
			'logUrl'     => $s['log_enabled'] ? esc_url_raw( rest_url( 'br-cookies/v1/consent' ) ) : '',
			'ownRows'    => array_merge(
				array(
					array(
						'provider' => $f['this_site'],
						'cookies'  => 'cc_cookie',
						'purpose'  => $f['own_purpose'],
						'lifetime' => $f['own_lifetime'],
					),
				),
				self::provider_rows( $s['providers'], 'necessary' )
			),
		);
	}

	// Wiersze trafiają do tabeli CookieConsent jako HTML, dlatego każda wartość jest zakodowana.
	private static function provider_rows( array $providers, $category ) {
		$rows = array();
		foreach ( $providers as $p ) {
			if ( $category !== $p['category'] ) {
				continue;
			}
			$name   = esc_html( $p['name'] );
			$rows[] = array(
				'provider' => $p['url'] ? '<a href="' . esc_url( $p['url'], array( 'http', 'https' ) ) . '" target="_blank" rel="noopener noreferrer">' . $name . '</a>' : $name,
				'cookies'  => esc_html( $p['cookies'] ),
				'purpose'  => esc_html( $p['purpose'] ),
				'lifetime' => esc_html( $p['lifetime'] ),
			);
		}
		return $rows;
	}

	public static function shortcode() {
		$lang = BR_Cookies_Settings::get()['language'];
		$f    = BR_Cookies_Settings::fixed_texts( $lang );
		return '<button type="button" class="br-cc-link" data-cc="show-preferencesModal">' . esc_html( $f['cookies_label'] ) . '</button>';
	}

	public static function start_blocker() {
		$s = BR_Cookies_Settings::get();
		if ( ( ! $s['block_maps'] && ! $s['block_video'] ) || self::in_builder() || is_feed() || is_robots() || is_trackback() ) {
			return;
		}
		ob_start(
			function ( $html ) use ( $s ) {
				return self::block_iframes( $html, $s['block_maps'], $s['block_video'] );
			}
		);
	}

	// Ramka nie może się załadować przed zgodą, więc jej adres przenosimy do data-atrybutu.
	public static function block_iframes( $html, $maps, $video ) {
		$hosts = array();
		if ( $maps ) {
			$hosts['map'] = 'www\.google\.[a-z.]+/maps/embed|maps\.google\.[a-z.]+/maps';
		}
		if ( $video ) {
			$hosts['video'] = '(?:www\.)?youtube(?:-nocookie)?\.com/embed/';
		}
		foreach ( $hosts as $kind => $pattern ) {
			$html = preg_replace(
				'#<iframe\b([^>]*?)\ssrc=(["\'])(https?:)?//(' . $pattern . ')([^"\']*)\2#i',
				'<iframe$1 data-br-kind="' . $kind . '" data-br-src=$2$3//$4$5$2',
				$html
			) ?? $html;
		}
		return $html;
	}
}
