<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Aktualizacje z własnego serwera. Zip instaluje się tylko z ważnym podpisem Ed25519,
 * dlatego przejęcie serwera aktualizacji bez klucza prywatnego nie wystarczy do podmiany kodu.
 */
class BR_Cookies_Updater {

	const CACHE_KEY = 'br_cookies_manifest';

	public static function init() {
		if ( ! self::enabled() ) {
			return;
		}
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'inject' ) );
		add_filter( 'upgrader_pre_download', array( __CLASS__, 'verify_download' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'auto_update' ), 10, 2 );
	}

	private static function enabled() {
		return 0 === stripos( BR_COOKIES_UPDATE_URL, 'https://' ) && '' !== BR_COOKIES_UPDATE_PUBLIC_KEY;
	}

	// Stała BR_COOKIES_AUTO_UPDATE ustawiona na false w wp-config.php wyłącza to na jednej stronie.
	public static function auto_update( $update, $item ) {
		if ( ! isset( $item->plugin ) || plugin_basename( BR_COOKIES_FILE ) !== $item->plugin ) {
			return $update;
		}
		return ! defined( 'BR_COOKIES_AUTO_UPDATE' ) || BR_COOKIES_AUTO_UPDATE;
	}

	private static function manifest() {
		$cached = get_site_transient( self::CACHE_KEY );
		if ( is_array( $cached ) ) {
			return $cached;
		}
		$response = wp_safe_remote_get( BR_COOKIES_UPDATE_URL, array( 'timeout' => 5 ) );
		$manifest = 200 === wp_remote_retrieve_response_code( $response ) ? json_decode( wp_remote_retrieve_body( $response ), true ) : null;
		if ( ! self::valid_manifest( $manifest ) ) {
			set_site_transient( self::CACHE_KEY, array(), HOUR_IN_SECONDS );
			return array();
		}
		set_site_transient( self::CACHE_KEY, $manifest, 6 * HOUR_IN_SECONDS );
		return $manifest;
	}

	public static function valid_manifest( $m ) {
		if ( ! is_array( $m ) || ! isset( $m['version'], $m['package'], $m['signature'] ) ) {
			return false;
		}
		$package_host = wp_parse_url( (string) $m['package'], PHP_URL_HOST );
		return preg_match( '/^\d+\.\d+\.\d+$/', (string) $m['version'] )
			&& 0 === stripos( (string) $m['package'], 'https://' )
			&& $package_host === wp_parse_url( BR_COOKIES_UPDATE_URL, PHP_URL_HOST );
	}

	public static function inject( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}
		$m = self::manifest();
		if ( ! $m || version_compare( $m['version'], BR_COOKIES_VERSION, '<=' ) ) {
			return $transient;
		}
		$basename                        = plugin_basename( BR_COOKIES_FILE );
		$transient->response[ $basename ] = (object) array(
			'slug'        => 'br-cookies',
			'plugin'      => $basename,
			'new_version' => $m['version'],
			'package'     => $m['package'],
			'url'         => 'https://brandrocks.pl',
		);
		return $transient;
	}

	public static function verify_download( $reply, $package, $upgrader ) {
		$m = self::manifest();
		if ( false !== $reply || ! $m || $package !== $m['package'] ) {
			return $reply;
		}
		$file = download_url( $package, 60 );
		if ( is_wp_error( $file ) ) {
			return $file;
		}
		if ( ! self::verify_file( $file, $m['version'], $m['signature'], BR_COOKIES_UPDATE_PUBLIC_KEY ) ) {
			wp_delete_file( $file );
			return new WP_Error( 'br_cookies_bad_signature', 'Aktualizacja BR Cookies ma nieprawidłowy podpis i nie została zainstalowana.' );
		}
		return $file;
	}

	// Podpis obejmuje też numer wersji, więc nie da się podstawić starszego, podatnego zipa jako nowego.
	public static function verify_file( $file, $version, $signature, $public_key ) {
		$sig = base64_decode( (string) $signature, true );
		$key = base64_decode( (string) $public_key, true );
		if ( false === $sig || false === $key || SODIUM_CRYPTO_SIGN_BYTES !== strlen( $sig ) || SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES !== strlen( $key ) ) {
			return false;
		}
		try {
			return sodium_crypto_sign_verify_detached( $sig, self::message( $version, hash_file( 'sha256', $file ) ), $key );
		} catch ( SodiumException $e ) {
			return false;
		}
	}

	public static function message( $version, $sha256 ) {
		return 'br-cookies|' . $version . '|' . $sha256;
	}
}
