<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BR_Cookies_Settings {

	const OPTION    = 'br_cookies_settings';
	const LANGUAGES = array( 'pl', 'en', 'de' );
	const COLORS    = array( 'bg', 'fg', 'accent', 'accent_fg', 'second', 'second_fg', 'icon_bg' );
	const CATEGORIES = array( 'analytics', 'marketing', 'media' );
	const MAX_PROVIDERS = 30;

	public static function default_texts() {
		return array(
			'pl' => array(
				'title'     => 'Cookies na tej stronie',
				'desc'      => 'Niezbędne pliki cookies zapewniają działanie strony. Za Twoją zgodą użyjemy też cookies analitycznych i reklamowych. Zgodę możesz w każdej chwili zmienić.',
				'accept'    => 'Akceptuję wszystkie',
				'reject'    => 'Odrzucam opcjonalne',
				'settings'  => 'Ustawienia',
				'analytics_name' => 'Analityczne',
				'analytics_desc' => 'Statystyki odwiedzin, które pomagają ulepszać stronę, np. Google Analytics.',
				'marketing_name' => 'Reklamowe',
				'marketing_desc' => 'Pozwalają mierzyć skuteczność reklam i dopasowywać ich treść.',
				'media_name'     => 'Multimedia i mapy',
				'media_desc'     => 'Wczytują treści zewnętrzne, np. Mapy Google i YouTube. Ich dostawcy mogą zapisać własne cookies.',
			),
			'en' => array(
				'title'     => 'Cookies on this site',
				'desc'      => 'Necessary cookies keep this site working. With your consent we will also use analytics and advertising cookies. You can change your choice at any time.',
				'accept'    => 'Accept all',
				'reject'    => 'Reject optional',
				'settings'  => 'Settings',
				'analytics_name' => 'Analytics',
				'analytics_desc' => 'Visit statistics that help us improve the site, e.g. Google Analytics.',
				'marketing_name' => 'Advertising',
				'marketing_desc' => 'Help us measure ad performance and tailor ad content.',
				'media_name'     => 'Media and maps',
				'media_desc'     => 'Load external content such as Google Maps and YouTube. These providers may set their own cookies.',
			),
			'de' => array(
				'title'     => 'Cookies auf dieser Website',
				'desc'      => 'Notwendige Cookies halten diese Website funktionsfähig. Mit Ihrer Einwilligung verwenden wir auch Analyse- und Werbe-Cookies. Sie können Ihre Auswahl jederzeit ändern.',
				'accept'    => 'Alle akzeptieren',
				'reject'    => 'Optionale ablehnen',
				'settings'  => 'Einstellungen',
				'analytics_name' => 'Analyse',
				'analytics_desc' => 'Besuchsstatistiken, mit denen wir die Website verbessern, z. B. Google Analytics.',
				'marketing_name' => 'Werbung',
				'marketing_desc' => 'Helfen, die Wirksamkeit von Anzeigen zu messen und deren Inhalte anzupassen.',
				'media_name'     => 'Medien und Karten',
				'media_desc'     => 'Laden externe Inhalte wie Google Maps und YouTube. Diese Anbieter können eigene Cookies setzen.',
			),
		);
	}

	// Napisy okna ustawień, których nie edytujemy w panelu.
	public static function fixed_texts( $lang ) {
		$all = array(
			'pl' => array(
				'prefs_title'    => 'Ustawienia cookies',
				'save'           => 'Zapisz wybór',
				'close'          => 'Zamknij',
				'necessary_name' => 'Niezbędne',
				'necessary_desc' => 'Potrzebne do działania strony i zapamiętania tego wyboru.',
				'more_title'     => 'Więcej informacji',
				'policy'         => 'Polityka prywatności',
				'cookies_label'  => 'Ustawienia cookies',
				'consent_id' => 'Identyfikator Twojej zgody',
				'col_provider' => 'Dostawca',
				'col_cookies' => 'Cookies',
				'col_purpose' => 'Cel',
				'col_lifetime' => 'Czas działania',
				'this_site' => 'Ta strona',
				'own_purpose' => 'Zapamiętanie wyboru cookies',
				'own_lifetime' => '6 miesięcy',
				'record_info' => 'Zapisujemy też identyfikator zgody, datę i wybrane kategorie jako dowód zgody, bez adresu IP.',
				'show_map'       => 'Pokaż mapę',
				'map_info'       => 'Mapa Google wczyta się dopiero po Twojej zgodzie.',
				'show_video'     => 'Pokaż film',
				'video_info'     => 'Film z YouTube wczyta się dopiero po Twojej zgodzie.',
			),
			'en' => array(
				'prefs_title'    => 'Cookie settings',
				'save'           => 'Save my choice',
				'close'          => 'Close',
				'necessary_name' => 'Necessary',
				'necessary_desc' => 'Required for the site to work and to remember this choice.',
				'more_title'     => 'More information',
				'policy'         => 'Privacy policy',
				'cookies_label'  => 'Cookie settings',
				'consent_id' => 'Your consent ID',
				'col_provider' => 'Provider',
				'col_cookies' => 'Cookies',
				'col_purpose' => 'Purpose',
				'col_lifetime' => 'Lifetime',
				'this_site' => 'This site',
				'own_purpose' => 'Remembering your cookie choice',
				'own_lifetime' => '6 months',
				'record_info' => 'We also store the consent ID, date and chosen categories as proof of consent, without your IP address.',
				'show_map'       => 'Show map',
				'map_info'       => 'Google Maps will only load after your consent.',
				'show_video'     => 'Show video',
				'video_info'     => 'The YouTube video will only load after your consent.',
			),
			'de' => array(
				'prefs_title'    => 'Cookie-Einstellungen',
				'save'           => 'Auswahl speichern',
				'close'          => 'Schließen',
				'necessary_name' => 'Notwendig',
				'necessary_desc' => 'Erforderlich für den Betrieb der Website und um diese Auswahl zu speichern.',
				'more_title'     => 'Weitere Informationen',
				'policy'         => 'Datenschutzerklärung',
				'cookies_label'  => 'Cookie-Einstellungen',
				'consent_id' => 'Ihre Einwilligungs-ID',
				'col_provider' => 'Anbieter',
				'col_cookies' => 'Cookies',
				'col_purpose' => 'Zweck',
				'col_lifetime' => 'Laufzeit',
				'this_site' => 'Diese Website',
				'own_purpose' => 'Speichern Ihrer Cookie-Auswahl',
				'own_lifetime' => '6 Monate',
				'record_info' => 'Wir speichern außerdem die Einwilligungs-ID, das Datum und die gewählten Kategorien als Nachweis, ohne Ihre IP-Adresse.',
				'show_map'       => 'Karte anzeigen',
				'map_info'       => 'Google Maps wird erst nach Ihrer Einwilligung geladen.',
				'show_video'     => 'Video anzeigen',
				'video_info'     => 'Das YouTube-Video wird erst nach Ihrer Einwilligung geladen.',
			),
		);
		return $all[ $lang ] ?? $all['pl'];
	}

	public static function defaults() {
		return array(
			'layout'      => 'box',
			'position'    => 'left',
			'radius'      => 8,
			'colors'      => array(
				'bg'        => '#ffffff',
				'fg'        => '#1d2327',
				'accent'    => '#c8102e',
				'accent_fg' => '#ffffff',
				'second'    => '#eaedf0',
				'second_fg' => '#1d2327',
				'icon_bg'   => '#c8102e',
			),
			'show_reject' => true,
			'show_icon'   => true,
			'language'    => 'pl',
			'policy_url'  => '/polityka-prywatnosci/',
			'texts'       => self::default_texts(),
			'categories'  => array(
				'analytics' => array( 'enabled' => true, 'cookies' => '_ga*, _gid' ),
				'marketing' => array( 'enabled' => true, 'cookies' => '_gcl*, _fbp, _fbc' ),
				'media'     => array( 'enabled' => true, 'cookies' => '' ),
			),
			'gcm'         => true,
			'block_maps'  => true,
			'block_video' => false,
			'gtm_event'   => false,
			'meta_pixel_id' => '',
			'providers'   => array(),
			'log_enabled' => true,
			'log_retention' => 24,
			'revision'    => 1,
		);
	}

	public static function get() {
		$saved = get_option( self::OPTION );
		return is_array( $saved ) ? self::merge( self::defaults(), $saved ) : self::defaults();
	}

	public static function merge( array $base, array $over ) {
		foreach ( $over as $key => $value ) {
			if ( ! array_key_exists( $key, $base ) ) {
				continue;
			}
			if ( 'providers' === $key ) {
				$base[ $key ] = is_array( $value ) ? array_values( $value ) : array();
				continue;
			}
			$base[ $key ] = is_array( $base[ $key ] ) && is_array( $value ) ? self::merge( $base[ $key ], $value ) : $value;
		}
		return $base;
	}

	/**
	 * Zapisuje wyłącznie znane pola. Brak pola typu tak/nie oznacza jego wyłączenie,
	 * bo tak przeglądarka wysyła niezaznaczony checkbox.
	 */
	public static function sanitize( $input ) {
		$d     = self::defaults();
		$input = is_array( $input ) ? $input : array();
		$old   = get_option( self::OPTION );
		$clean = array();

		$clean['layout']   = self::choice( $input['layout'] ?? '', array( 'box', 'bar' ), $d['layout'] );
		$clean['position'] = self::choice( $input['position'] ?? '', array( 'left', 'center', 'right' ), $d['position'] );
		$clean['radius']   = max( 0, min( 24, (int) ( $input['radius'] ?? $d['radius'] ) ) );

		foreach ( self::COLORS as $key ) {
			$color                  = sanitize_hex_color( $input['colors'][ $key ] ?? '' );
			$clean['colors'][ $key ] = $color ? $color : $d['colors'][ $key ];
		}

		$clean['show_reject'] = ! empty( $input['show_reject'] );
		$clean['show_icon']   = ! empty( $input['show_icon'] );
		$clean['language']    = self::choice( $input['language'] ?? '', self::LANGUAGES, $d['language'] );
		$clean['policy_url']  = self::policy_url( $input['policy_url'] ?? '', $d['policy_url'] );

		foreach ( self::LANGUAGES as $lang ) {
			foreach ( $d['texts'][ $lang ] as $key => $default ) {
				$value = $input['texts'][ $lang ][ $key ] ?? '';
				$value = 'desc' === substr( $key, -4 ) ? sanitize_textarea_field( (string) $value ) : sanitize_text_field( (string) $value );
				$clean['texts'][ $lang ][ $key ] = '' !== trim( $value ) ? $value : $default;
			}
		}

		foreach ( self::CATEGORIES as $cat ) {
			$clean['categories'][ $cat ] = array(
				'enabled' => ! empty( $input['categories'][ $cat ]['enabled'] ),
				'cookies' => self::cookie_list( $input['categories'][ $cat ]['cookies'] ?? '' ),
			);
		}

		$clean['gcm']         = ! empty( $input['gcm'] );
		$clean['block_maps']  = ! empty( $input['block_maps'] );
		$clean['block_video'] = ! empty( $input['block_video'] );
		$clean['gtm_event']   = ! empty( $input['gtm_event'] );

		$pixel                  = trim( (string) ( $input['meta_pixel_id'] ?? '' ) );
		$clean['meta_pixel_id'] = preg_match( '/^\d{5,20}$/', $pixel ) ? $pixel : '';

		$clean['providers']     = self::providers( $input['providers'] ?? array() );
		$clean['log_enabled']   = ! empty( $input['log_enabled'] );
		$clean['log_retention'] = max( 1, min( 60, (int) ( $input['log_retention'] ?? $d['log_retention'] ) ) );

		// Numer zgody zmienia tylko przycisk „Resetuj zgody”, nigdy formularz ani import.
		$current           = is_array( $old ) && isset( $old['revision'] ) ? (int) $old['revision'] : $d['revision'];
		$clean['revision'] = ! empty( $input['_bump_revision'] ) ? $current + 1 : $current;

		return $clean;
	}

	private static function choice( $value, array $allowed, $default ) {
		return in_array( $value, $allowed, true ) ? $value : $default;
	}

	// Dozwolone są tylko adresy http(s) i ścieżki na tej samej domenie.
	private static function policy_url( $value, $default ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return $default;
		}
		if ( '/' === $value[0] && ( ! isset( $value[1] ) || '/' !== $value[1] ) ) {
			return esc_url_raw( $value, array( 'http', 'https' ) ) ?: $default;
		}
		$url = esc_url_raw( $value, array( 'http', 'https' ) );
		return $url && preg_match( '#^https?://#i', $url ) ? $url : $default;
	}

	private static function providers( $rows ) {
		$clean   = array();
		$allowed = array_merge( array( 'necessary' ), self::CATEGORIES );
		foreach ( array_slice( is_array( $rows ) ? array_values( $rows ) : array(), 0, self::MAX_PROVIDERS ) as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$name = sanitize_text_field( (string) ( $row['name'] ?? '' ) );
			if ( '' === $name ) {
				continue;
			}
			$url     = esc_url_raw( trim( (string) ( $row['url'] ?? '' ) ), array( 'http', 'https' ) );
			$clean[] = array(
				'name'     => $name,
				'category' => self::choice( $row['category'] ?? '', $allowed, 'analytics' ),
				'cookies'  => self::cookie_list( $row['cookies'] ?? '' ),
				'purpose'  => sanitize_text_field( (string) ( $row['purpose'] ?? '' ) ),
				'lifetime' => sanitize_text_field( (string) ( $row['lifetime'] ?? '' ) ),
				'url'      => preg_match( '#^https?://#i', $url ) ? $url : '',
			);
		}
		return $clean;
	}

	private static function cookie_list( $value ) {
		$names = array_filter(
			array_map(
				function ( $name ) {
					return preg_replace( '/[^A-Za-z0-9_.*-]/', '', trim( $name ) );
				},
				explode( ',', (string) $value )
			)
		);
		return implode( ', ', array_slice( $names, 0, 50 ) );
	}
}
