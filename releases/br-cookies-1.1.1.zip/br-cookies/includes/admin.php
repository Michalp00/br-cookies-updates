<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BR_Cookies_Admin {

	const SLUG        = 'br-cookies';
	const MAX_IMPORT  = 65536;

	public static function init( $conflict ) {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
		add_action( 'admin_post_br_cookies_export', array( __CLASS__, 'export' ) );
		add_action( 'admin_post_br_cookies_import', array( __CLASS__, 'import' ) );
		add_action( 'admin_post_br_cookies_reset', array( __CLASS__, 'reset_consents' ) );
		add_action( 'admin_post_br_cookies_log_csv', array( __CLASS__, 'log_csv' ) );
		add_action( 'update_option_' . BR_Cookies_Settings::OPTION, array( __CLASS__, 'purge_cache' ) );
		add_action( 'add_option_' . BR_Cookies_Settings::OPTION, array( __CLASS__, 'purge_cache' ) );

		if ( $conflict ) {
			add_action(
				'admin_notices',
				function () {
					echo '<div class="notice notice-error"><p><strong>BR Cookies nie działa na stronie:</strong> włączona jest stara wtyczka Jet Boat Cookie Consent. Wyłącz ją, żeby nie było dwóch banerów.</p></div>';
				}
			);
		}
	}

	public static function menu() {
		add_options_page( 'BR Cookies', 'BR Cookies', 'manage_options', self::SLUG, array( __CLASS__, 'render' ) );
	}

	public static function register() {
		register_setting(
			'br_cookies',
			BR_Cookies_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( 'BR_Cookies_Settings', 'sanitize' ),
				'default'           => BR_Cookies_Settings::defaults(),
			)
		);
	}

	public static function assets( $hook ) {
		if ( 'settings_page_' . self::SLUG !== $hook ) {
			return;
		}
		$url = plugin_dir_url( BR_COOKIES_FILE ) . 'assets/';
		wp_enqueue_style( 'br-cookies-admin', $url . 'admin.css', array(), BR_COOKIES_VERSION );
		wp_enqueue_script( 'br-cookies-admin', $url . 'admin.js', array(), BR_COOKIES_VERSION, true );
	}

	public static function purge_cache() {
		do_action( 'litespeed_purge_all' );
		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
		}
		if ( function_exists( 'w3tc_flush_all' ) ) {
			w3tc_flush_all();
		}
	}

	private static function guard( $action ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Brak uprawnień.', '', array( 'response' => 403 ) );
		}
		check_admin_referer( $action );
	}

	private static function back( $notice ) {
		wp_safe_redirect( add_query_arg( array( 'page' => self::SLUG, 'br_notice' => $notice, 'tab' => 'tools' ), admin_url( 'options-general.php' ) ) );
		exit;
	}

	public static function export() {
		self::guard( 'br_cookies_export' );
		$data = BR_Cookies_Settings::get();
		unset( $data['revision'] );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="br-cookies-' . sanitize_file_name( wp_parse_url( home_url(), PHP_URL_HOST ) ) . '.json"' );
		echo wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
		exit;
	}

	public static function import() {
		self::guard( 'br_cookies_import' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- plik jest sprawdzany poniżej i czytany wyłącznie jako JSON.
		$file = $_FILES['br_cookies_file'] ?? null;
		if ( ! is_array( $file ) || UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) || (int) $file['size'] > self::MAX_IMPORT ) {
			self::back( 'import_error' );
		}
		$data = json_decode( (string) file_get_contents( $file['tmp_name'], false, null, 0, self::MAX_IMPORT ), true );
		if ( ! is_array( $data ) || ! isset( $data['colors'], $data['texts'], $data['categories'] ) ) {
			self::back( 'import_error' );
		}
		unset( $data['revision'], $data['_bump_revision'] );
		update_option( BR_Cookies_Settings::OPTION, BR_Cookies_Settings::merge( BR_Cookies_Settings::defaults(), $data ) );
		self::back( 'import_ok' );
	}

	public static function reset_consents() {
		self::guard( 'br_cookies_reset' );
		$data                   = BR_Cookies_Settings::get();
		$data['_bump_revision'] = true;
		update_option( BR_Cookies_Settings::OPTION, $data );
		self::back( 'reset_ok' );
	}

	public static function log_csv() {
		self::guard( 'br_cookies_log_csv' );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="br-cookies-rejestr-' . gmdate( 'Y-m-d' ) . '.csv"' );
		$out = fopen( 'php://output', 'w' );
		fputcsv( $out, array( 'id_zgody', 'data_utc', 'numer_zgody', 'kategorie', 'wybor', 'zdarzenie', 'wersja_banera' ), ',', '"', '\\' );
		$batch  = 1000;
		$offset = 0;
		do {
			$rows = BR_Cookies_Log::rows( $batch, $offset );
			foreach ( $rows as $r ) {
				fputcsv( $out, array( $r->consent_id, $r->created_at, $r->revision, $r->categories, $r->choice, $r->event, $r->banner_version ), ',', '"', '\\' );
			}
			$offset += $batch;
		} while ( count( $rows ) === $batch );
		exit;
	}

	private static function provider_row( $index, array $p, array $cat_labels ) {
		$name = esc_attr( BR_Cookies_Settings::OPTION . '[providers][' . $index . ']' );
		$val  = function ( $key ) use ( $p ) {
			return esc_attr( $p[ $key ] ?? '' );
		};
		ob_start();
		?>
		<div class="br-provider" data-provider>
			<label class="br-field"><span>Dostawca</span><input type="text" data-field="name" name="<?php echo $name; // phpcs:ignore WordPress.Security.EscapeOutput ?>[name]" value="<?php echo $val( 'name' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>"></label>
			<label class="br-field"><span>Kategoria</span><select data-field="category" name="<?php echo $name; // phpcs:ignore WordPress.Security.EscapeOutput ?>[category]">
				<?php foreach ( array_merge( array( 'necessary' => 'Niezbędne' ), $cat_labels ) as $id => $label ) : ?>
					<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $p['category'] ?? 'analytics', $id ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select></label>
			<label class="br-field"><span>Cookies</span><input type="text" data-field="cookies" name="<?php echo $name; // phpcs:ignore WordPress.Security.EscapeOutput ?>[cookies]" value="<?php echo $val( 'cookies' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>"></label>
			<label class="br-field"><span>Cel</span><input type="text" data-field="purpose" name="<?php echo $name; // phpcs:ignore WordPress.Security.EscapeOutput ?>[purpose]" value="<?php echo $val( 'purpose' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>"></label>
			<label class="br-field"><span>Czas działania</span><input type="text" data-field="lifetime" name="<?php echo $name; // phpcs:ignore WordPress.Security.EscapeOutput ?>[lifetime]" value="<?php echo $val( 'lifetime' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>"></label>
			<label class="br-field"><span>Polityka prywatności dostawcy</span><input type="url" data-field="url" name="<?php echo $name; // phpcs:ignore WordPress.Security.EscapeOutput ?>[url]" value="<?php echo $val( 'url' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>"></label>
			<button type="button" class="button-link button-link-delete" data-remove>Usuń dostawcę</button>
		</div>
		<?php
		return ob_get_clean();
	}

	public static function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$s     = BR_Cookies_Settings::get();
		$name  = BR_Cookies_Settings::OPTION;
		$field = function ( $path ) use ( $name ) {
			return esc_attr( $name . '[' . implode( '][', $path ) . ']' );
		};
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- tylko wybór zakładki i komunikatu z ustalonej listy.
		$notice = sanitize_key( $_GET['br_notice'] ?? '' );
		$tab    = sanitize_key( $_GET['tab'] ?? 'look' );
		$search = trim( sanitize_text_field( wp_unslash( $_GET['br_consent'] ?? '' ) ) );
		// phpcs:enable

		$log_rows = BR_Cookies_Log::rows( 50, 0, $search );
		$choices  = array( 'all' => 'Wszystkie', 'necessary' => 'Tylko niezbędne', 'custom' => 'Wybrane' );

		$notices = array(
			'import_ok'    => array( 'success', 'Zaimportowano ustawienia.' ),
			'import_error' => array( 'error', 'Nie udało się wczytać pliku. Użyj pliku JSON wyeksportowanego z BR Cookies (do 64 KB).' ),
			'reset_ok'     => array( 'success', 'Zgody zresetowane. Baner wróci u każdego użytkownika.' ),
		);
		$tabs    = array(
			'look'         => 'Wygląd',
			'texts'        => 'Treści',
			'categories'   => 'Kategorie',
			'providers'    => 'Dostawcy',
			'integrations' => 'Integracje',
			'log'          => 'Rejestr zgód',
			'tools'        => 'Narzędzia',
		);
		$colors  = array(
			'bg'        => 'Tło banera',
			'fg'        => 'Tekst',
			'accent'    => 'Przyciski Akceptuj i Odrzuć',
			'accent_fg' => 'Tekst na tych przyciskach',
			'second'    => 'Przycisk Ustawienia',
			'second_fg' => 'Tekst przycisku Ustawienia',
			'icon_bg'   => 'Ikona zgód',
		);
		$lang_names = array( 'pl' => 'Polski', 'en' => 'English', 'de' => 'Deutsch' );
		$text_rows  = array(
			'title'    => 'Tytuł',
			'accept'   => 'Przycisk Akceptuj',
			'reject'   => 'Przycisk Odrzuć',
			'settings' => 'Przycisk Ustawienia',
		);
		$cat_labels = array( 'analytics' => 'Analityczne', 'marketing' => 'Reklamowe', 'media' => 'Multimedia i mapy' );
		$integrations = array(
			'gcm'         => array( 'Google Consent Mode v2', 'Ustawia brak zgody przed startem GTM i aktualizuje go po decyzji użytkownika.' ),
			'block_maps'  => array( 'Blokuj Mapy Google do czasu zgody', 'Zamiast ramki z mapą pokazuje przycisk „Pokaż mapę”.' ),
			'block_video' => array( 'Blokuj filmy YouTube do czasu zgody', 'Działa na ramkach iframe w kodzie strony. Sprawdź to przy widżecie wideo Elementora, który może ładować film skryptem.' ),
			'gtm_event'   => array( 'Wysyłaj zdarzenie do GTM po decyzji', 'Zdarzenie br_consent_update pozwala podpiąć tagi innych firm, np. piksel Mety.' ),
		);
		?>
		<div class="wrap br-wrap">
			<h1>BR Cookies</h1>
			<?php if ( isset( $notices[ $notice ] ) ) : ?>
				<div class="notice notice-<?php echo esc_attr( $notices[ $notice ][0] ); ?> is-dismissible"><p><?php echo esc_html( $notices[ $notice ][1] ); ?></p></div>
			<?php endif; ?>
			<?php settings_errors(); ?>

			<div class="br-tabs" role="tablist" aria-label="Sekcje ustawień">
				<?php foreach ( $tabs as $id => $label ) : ?>
					<button type="button" role="tab" class="br-tab" data-tab="<?php echo esc_attr( $id ); ?>" aria-selected="<?php echo $tab === $id ? 'true' : 'false'; ?>"><?php echo esc_html( $label ); ?></button>
				<?php endforeach; ?>
			</div>

			<div class="br-layout">
				<div class="br-settings">
					<form method="post" action="options.php" id="br-form">
						<?php settings_fields( 'br_cookies' ); ?>

						<div class="br-panel" data-panel="look">
							<section class="br-card">
								<h2>Układ banera</h2>
								<div class="br-seg">
									<label><input type="radio" name="<?php echo $field( array( 'layout' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="box" <?php checked( $s['layout'], 'box' ); ?>><span>Okienko</span></label>
									<label><input type="radio" name="<?php echo $field( array( 'layout' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="bar" <?php checked( $s['layout'], 'bar' ); ?>><span>Pasek na całą szerokość</span></label>
								</div>
								<div class="br-group" id="br-position">
									<strong>Pozycja</strong>
									<div class="br-seg">
										<?php foreach ( array( 'left' => 'Lewy dół', 'center' => 'Środek', 'right' => 'Prawy dół' ) as $value => $label ) : ?>
											<label><input type="radio" name="<?php echo $field( array( 'position' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="<?php echo esc_attr( $value ); ?>" <?php checked( $s['position'], $value ); ?>><span><?php echo esc_html( $label ); ?></span></label>
										<?php endforeach; ?>
									</div>
								</div>
								<label class="br-field"><span>Zaokrąglenie narożników: <output id="br-radius-out"><?php echo (int) $s['radius']; ?></output> px</span>
									<input type="range" min="0" max="24" name="<?php echo $field( array( 'radius' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="<?php echo (int) $s['radius']; ?>">
								</label>
							</section>

							<section class="br-card">
								<h2>Kolory</h2>
								<?php foreach ( $colors as $key => $label ) : ?>
									<label class="br-color"><span><?php echo esc_html( $label ); ?></span>
										<span class="br-color-input"><code><?php echo esc_html( $s['colors'][ $key ] ); ?></code>
											<input type="color" data-color="<?php echo esc_attr( $key ); ?>" name="<?php echo $field( array( 'colors', $key ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="<?php echo esc_attr( $s['colors'][ $key ] ); ?>">
										</span>
									</label>
								<?php endforeach; ?>
							</section>

							<section class="br-card">
								<h2>Przyciski i ikona</h2>
								<label class="br-check"><input type="checkbox" id="br-show-reject" name="<?php echo $field( array( 'show_reject' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="1" <?php checked( $s['show_reject'] ); ?>>
									<span><strong>Pokaż przycisk Odrzuć na banerze</strong><small>Domyślnie włączone. Po wyłączeniu odrzucić można tylko w Ustawieniach.</small></span></label>
								<div class="br-warning" id="br-reject-warning" role="alert" <?php echo $s['show_reject'] ? 'hidden' : ''; ?>>
									<strong>Ryzyko prawne.</strong> Większość europejskich urzędów ochrony danych uznaje baner bez możliwości odrzucenia za niezgodny z wymogami zgody. Odrzucić nadal można w „Ustawieniach”. Włączaj tę opcję tylko po decyzji klienta.
								</div>
								<label class="br-check"><input type="checkbox" id="br-show-icon" name="<?php echo $field( array( 'show_icon' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="1" <?php checked( $s['show_icon'] ); ?>>
									<span><strong>Ikona zgód po zamknięciu banera</strong><small>Stała ikona w lewym dolnym rogu otwiera ustawienia.</small></span></label>
							</section>
						</div>

						<div class="br-panel" data-panel="texts">
							<section class="br-card">
								<h2>Treści banera</h2>
								<label class="br-field"><span>Język banera</span>
									<select id="br-language" name="<?php echo $field( array( 'language' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>">
										<?php foreach ( $lang_names as $code => $label ) : ?>
											<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $s['language'], $code ); ?>><?php echo esc_html( $label ); ?></option>
										<?php endforeach; ?>
									</select>
								</label>
								<?php foreach ( $lang_names as $code => $label ) : ?>
									<div class="br-lang" data-lang="<?php echo esc_attr( $code ); ?>">
										<?php foreach ( $text_rows as $key => $row ) : ?>
											<label class="br-field"><span><?php echo esc_html( $row ); ?></span>
												<input type="text" data-text="<?php echo esc_attr( $key ); ?>" name="<?php echo $field( array( 'texts', $code, $key ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="<?php echo esc_attr( $s['texts'][ $code ][ $key ] ); ?>">
											</label>
										<?php endforeach; ?>
										<label class="br-field"><span>Opis</span>
											<textarea rows="4" data-text="desc" name="<?php echo $field( array( 'texts', $code, 'desc' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>"><?php echo esc_textarea( $s['texts'][ $code ]['desc'] ); ?></textarea>
										</label>
									</div>
								<?php endforeach; ?>
								<label class="br-field"><span>Adres polityki prywatności</span>
									<input type="text" name="<?php echo $field( array( 'policy_url' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="<?php echo esc_attr( $s['policy_url'] ); ?>">
								</label>
							</section>
						</div>

						<div class="br-panel" data-panel="categories">
							<section class="br-card">
								<h2>Kategorie zgód</h2>
								<p class="description">Pokazuj tylko te kategorie, których strona używa. Po wycofaniu zgody wtyczka usunie wymienione cookies (* oznacza dowolny ciąg znaków).</p>
								<label class="br-check"><input type="checkbox" checked disabled>
									<span><strong>Niezbędne</strong><small>Zawsze włączone, użytkownik nie może ich wyłączyć.</small></span></label>
								<?php foreach ( $cat_labels as $cat => $label ) : ?>
									<div class="br-cat">
										<label class="br-check"><input type="checkbox" name="<?php echo $field( array( 'categories', $cat, 'enabled' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="1" <?php checked( $s['categories'][ $cat ]['enabled'] ); ?>>
											<span><strong><?php echo esc_html( $label ); ?></strong></span></label>
										<?php foreach ( $lang_names as $code => $lang_label ) : ?>
											<div class="br-lang" data-lang="<?php echo esc_attr( $code ); ?>">
												<label class="br-field"><span>Nazwa</span>
													<input type="text" name="<?php echo $field( array( 'texts', $code, $cat . '_name' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="<?php echo esc_attr( $s['texts'][ $code ][ $cat . '_name' ] ); ?>"></label>
												<label class="br-field"><span>Opis</span>
													<textarea rows="2" name="<?php echo $field( array( 'texts', $code, $cat . '_desc' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>"><?php echo esc_textarea( $s['texts'][ $code ][ $cat . '_desc' ] ); ?></textarea></label>
											</div>
										<?php endforeach; ?>
										<label class="br-field"><span>Cookies do usunięcia</span>
											<input type="text" name="<?php echo $field( array( 'categories', $cat, 'cookies' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="<?php echo esc_attr( $s['categories'][ $cat ]['cookies'] ); ?>"></label>
									</div>
								<?php endforeach; ?>
							</section>
						</div>

						<div class="br-panel" data-panel="providers">
							<section class="br-card">
								<h2>Dostawcy i cookies</h2>
								<p class="description">Lista pojawi się w oknie ustawień, przy swojej kategorii. Wpisz tylko usługi, których strona faktycznie używa, i sprawdź czasy działania cookies. Wpisuj w języku banera.</p>
								<div class="br-seg-buttons" id="br-presets">
									<?php foreach ( array( 'ga' => 'Google Analytics', 'ads' => 'Google Ads', 'meta' => 'Piksel Mety', 'maps' => 'Mapy Google', 'youtube' => 'YouTube' ) as $id => $label ) : ?>
										<button type="button" class="button" data-preset="<?php echo esc_attr( $id ); ?>">+ <?php echo esc_html( $label ); ?></button>
									<?php endforeach; ?>
									<button type="button" class="button" data-preset="">+ Inny dostawca</button>
								</div>
								<div id="br-providers">
									<?php
									foreach ( $s['providers'] as $i => $provider ) {
										echo self::provider_row( $i, $provider, $cat_labels ); // phpcs:ignore WordPress.Security.EscapeOutput -- wartości zakodowane w provider_row.
									}
									?>
								</div>
								<template id="br-provider-template"><?php echo self::provider_row( '__i__', array(), $cat_labels ); // phpcs:ignore WordPress.Security.EscapeOutput ?></template>
							</section>
						</div>

						<div class="br-panel" data-panel="integrations">
							<section class="br-card">
								<h2>Integracje</h2>
								<?php foreach ( $integrations as $key => $row ) : ?>
									<label class="br-check"><input type="checkbox" name="<?php echo $field( array( $key ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="1" <?php checked( $s[ $key ] ); ?>>
										<span><strong><?php echo esc_html( $row[0] ); ?></strong><small><?php echo esc_html( $row[1] ); ?></small></span></label>
								<?php endforeach; ?>
								<label class="br-field br-pixel"><span>ID piksela Mety</span>
									<input type="text" inputmode="numeric" pattern="[0-9]{5,20}" name="<?php echo $field( array( 'meta_pixel_id' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="<?php echo esc_attr( $s['meta_pixel_id'] ); ?>">
								</label>
								<p class="description">Piksel załaduje się dopiero po zgodzie na kategorię Reklamowe i wyśle PageView. Zostaw puste, jeśli piksel jest już w GTM, bo inaczej zdarzenia policzą się podwójnie.</p>
								<p class="description">Link do ustawień możesz wstawić w dowolnym miejscu krótkim kodem <code>[br_cookies_settings]</code>.</p>
							</section>
						</div>

						<div class="br-panel" data-panel="log">
							<section class="br-card">
								<h2>Rejestr zgód</h2>
								<label class="br-check"><input type="checkbox" name="<?php echo $field( array( 'log_enabled' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="1" <?php checked( $s['log_enabled'] ); ?>>
									<span><strong>Zapisuj decyzje użytkowników</strong><small>Identyfikator zgody, data, kategorie i wersja banera, bez adresu IP. Opisz rejestr w polityce prywatności.</small></span></label>
								<label class="br-field"><span>Przechowuj przez (miesiące)</span>
									<input type="number" min="1" max="60" name="<?php echo $field( array( 'log_retention' ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>" value="<?php echo (int) $s['log_retention']; ?>"></label>
								<p class="description">Starsze wpisy usuwają się automatycznie. Odinstalowanie wtyczki kasuje rejestr, więc wcześniej pobierz CSV.</p>
							</section>
						</div>

						<p class="br-save" data-save><?php submit_button( 'Zapisz zmiany', 'primary', 'submit', false ); ?></p>
					</form>

					<div class="br-panel" data-panel="log">
						<section class="br-card">
							<h2>Zapisane zgody: <?php echo (int) BR_Cookies_Log::count(); ?></h2>
							<form method="get" action="<?php echo esc_url( admin_url( 'options-general.php' ) ); ?>" class="br-log-search">
								<input type="hidden" name="page" value="<?php echo esc_attr( self::SLUG ); ?>">
								<input type="hidden" name="tab" value="log">
								<label class="br-field"><span>Szukaj po identyfikatorze zgody</span><input type="text" name="br_consent" value="<?php echo esc_attr( $search ); ?>"></label>
								<button class="button">Szukaj</button>
							</form>
							<div class="br-log-table">
								<table class="widefat striped">
									<thead><tr><th>Data (UTC)</th><th>Identyfikator</th><th>Wybór</th><th>Kategorie</th><th>Wersja</th></tr></thead>
									<tbody>
										<?php foreach ( $log_rows as $r ) : ?>
											<tr><td><?php echo esc_html( $r->created_at ); ?></td><td><code><?php echo esc_html( $r->consent_id ); ?></code></td><td><?php echo esc_html( $choices[ $r->choice ] ?? $r->choice ); ?></td><td><?php echo esc_html( $r->categories ); ?></td><td><code><?php echo esc_html( $r->revision . '/' . $r->banner_version ); ?></code></td></tr>
										<?php endforeach; ?>
										<?php if ( ! $log_rows ) : ?>
											<tr><td colspan="5">Brak wpisów.</td></tr>
										<?php endif; ?>
									</tbody>
								</table>
							</div>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="br_cookies_log_csv">
								<?php wp_nonce_field( 'br_cookies_log_csv' ); ?>
								<button class="button">Pobierz CSV</button>
							</form>
						</section>
					</div>

					<div class="br-panel" data-panel="tools">
						<section class="br-card">
							<h2>Przenoszenie między stronami</h2>
							<p class="description">Wyeksportuj ustawienia i wgraj je na kolejną stronę jednym plikiem.</p>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="br_cookies_export">
								<?php wp_nonce_field( 'br_cookies_export' ); ?>
								<button class="button">Eksportuj ustawienia</button>
							</form>
							<form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="br-import">
								<input type="hidden" name="action" value="br_cookies_import">
								<?php wp_nonce_field( 'br_cookies_import' ); ?>
								<label class="br-field"><span>Plik JSON</span><input type="file" name="br_cookies_file" accept=".json,application/json" required></label>
								<button class="button">Importuj plik</button>
							</form>
						</section>
						<section class="br-card">
							<h2>Poproś wszystkich o zgodę ponownie</h2>
							<p class="description">Na przykład po dodaniu nowego narzędzia reklamowego. Baner wróci u każdego użytkownika.</p>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="br-reset">
								<input type="hidden" name="action" value="br_cookies_reset">
								<?php wp_nonce_field( 'br_cookies_reset' ); ?>
								<button class="button">Resetuj zgody</button>
							</form>
						</section>
					</div>
				</div>

				<aside class="br-preview-card">
					<div class="br-preview-head">
						<h2>Podgląd na żywo</h2>
						<div class="br-preview-tools">
							<button type="button" class="button" data-device="desktop" aria-pressed="true">Komputer</button>
							<button type="button" class="button" data-device="phone" aria-pressed="false">Telefon</button>
							<button type="button" class="button" id="br-preview-done">Pokaż po decyzji</button>
						</div>
					</div>
					<div class="br-stage" id="br-stage">
						<div class="br-fake" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
						<div class="br-demo" id="br-demo">
							<strong id="br-demo-title"></strong>
							<p id="br-demo-desc"></p>
							<div class="br-demo-btns">
								<span id="br-demo-accept"></span>
								<span id="br-demo-reject"></span>
								<span id="br-demo-settings"></span>
							</div>
						</div>
						<span class="br-demo-icon" id="br-demo-icon" hidden>
							<svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" fill="currentColor"><path d="M21.6 11.2a4 4 0 0 1-4.3-3.5 4 4 0 0 1-4.9-4.9A9.5 9.5 0 1 0 21.6 11.2zM8 9.5A1.5 1.5 0 1 1 8 12.5 1.5 1.5 0 0 1 8 9.5zm1 6a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm6 .5a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3zm-2.5-4a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/></svg>
						</span>
					</div>
				</aside>
			</div>
		</div>
		<?php
	}
}
