<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rejestr zgód: dowód, jaki wybór zapadł, kiedy i przy jakiej treści banera.
 * Celowo bez IP i user agenta. Identyfikator zgody powstaje losowo w przeglądarce.
 */
class BR_Cookies_Log {

	const DB_VERSION    = '1';
	const DB_OPTION     = 'br_cookies_db_version';
	const VERSIONS      = 'br_cookies_banner_versions';
	const CRON          = 'br_cookies_purge';
	const RATE_LIMIT    = 120;
	const RATE_WINDOW   = 600;
	const ID_PATTERN    = '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i';

	public static function init() {
		if ( get_option( self::DB_OPTION ) !== self::DB_VERSION ) {
			self::install();
		}
		add_action( 'rest_api_init', array( __CLASS__, 'routes' ) );
		add_action( self::CRON, array( __CLASS__, 'purge' ) );
		if ( ! wp_next_scheduled( self::CRON ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::CRON );
		}
	}

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'br_cookies_consents';
	}

	public static function install() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				consent_id char(36) NOT NULL,
				created_at datetime NOT NULL,
				revision int(10) unsigned NOT NULL,
				categories varchar(100) NOT NULL,
				choice varchar(10) NOT NULL,
				event varchar(10) NOT NULL,
				banner_version char(12) NOT NULL,
				PRIMARY KEY  (id),
				KEY consent_id (consent_id),
				KEY created_at (created_at)
			) {$charset};"
		);
		update_option( self::DB_OPTION, self::DB_VERSION, false );
	}

	public static function routes() {
		// Trasa jest publiczna, bo baner widzą też niezalogowani, a strony bywają w cache, więc nonce by wygasał.
		register_rest_route(
			'br-cookies/v1',
			'/consent',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => array( __CLASS__, 'handle' ),
				'args'                => array(
					'consent_id' => array(
						'required'          => true,
						'type'              => 'string',
						'validate_callback' => function ( $value ) {
							return is_string( $value ) && preg_match( self::ID_PATTERN, $value );
						},
					),
					'categories' => array(
						'required'          => true,
						'type'              => 'array',
						'validate_callback' => function ( $value ) {
							return is_array( $value ) && count( $value ) <= 10;
						},
					),
					'event'      => array(
						'required' => true,
						'type'     => 'string',
						'enum'     => array( 'first', 'change' ),
					),
				),
			)
		);
	}

	public static function handle( WP_REST_Request $request ) {
		$s = BR_Cookies_Settings::get();
		if ( empty( $s['log_enabled'] ) ) {
			return new WP_REST_Response( array( 'saved' => false ), 200 );
		}
		if ( self::rate_limited() ) {
			return new WP_Error( 'br_cookies_rate_limited', 'Za dużo żądań.', array( 'status' => 429 ) );
		}

		$enabled = array();
		foreach ( BR_Cookies_Settings::CATEGORIES as $cat ) {
			if ( $s['categories'][ $cat ]['enabled'] ) {
				$enabled[] = $cat;
			}
		}
		$sent     = array_filter( (array) $request['categories'], 'is_string' );
		$accepted = array_values( array_intersect( $enabled, $sent ) );
		$choice   = ! $accepted ? 'necessary' : ( count( $accepted ) === count( $enabled ) ? 'all' : 'custom' );
		$cats     = implode( ',', array_merge( array( 'necessary' ), $accepted ) );

		global $wpdb;
		$table = self::table();
		$id    = strtolower( (string) $request['consent_id'] );
		$rev   = (int) $s['revision'];

		// Ten sam wybór wysłany ponownie nie tworzy nowego wpisu.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- nazwa tabeli jest stała.
		$last = $wpdb->get_row( $wpdb->prepare( "SELECT categories, revision FROM {$table} WHERE consent_id = %s ORDER BY id DESC LIMIT 1", $id ) );
		if ( $last && $last->categories === $cats && (int) $last->revision === $rev ) {
			return new WP_REST_Response( array( 'saved' => false ), 200 );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert(
			$table,
			array(
				'consent_id'     => $id,
				'created_at'     => gmdate( 'Y-m-d H:i:s' ),
				'revision'       => $rev,
				'categories'     => $cats,
				'choice'         => $choice,
				'event'          => (string) $request['event'],
				'banner_version' => self::banner_version( $s ),
			),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);
		return new WP_REST_Response( array( 'saved' => true ), 201 );
	}

	// Skrót adresu IP żyje tylko przez okno limitu i nie trafia do rejestru.
	private static function rate_limited() {
		$ip    = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- używany tylko jako wejście HMAC.
		$key   = 'br_cc_rl_' . substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 32 );
		$count = (int) get_transient( $key );
		if ( $count >= self::RATE_LIMIT ) {
			return true;
		}
		set_transient( $key, $count + 1, self::RATE_WINDOW );
		return false;
	}

	// Zapamiętuje treść pokazaną użytkownikowi, żeby wpis w rejestrze dało się z nią powiązać.
	public static function banner_version( array $s ) {
		$lang     = $s['language'];
		$snapshot = array(
			'language'    => $lang,
			'texts'       => $s['texts'][ $lang ],
			'show_reject' => $s['show_reject'],
			'providers'   => $s['providers'],
			'policy_url'  => $s['policy_url'],
		);
		$hash     = substr( hash( 'sha256', (string) wp_json_encode( $snapshot ) ), 0, 12 );
		$versions = get_option( self::VERSIONS, array() );
		$versions = is_array( $versions ) ? $versions : array();
		if ( ! isset( $versions[ $hash ] ) ) {
			$versions[ $hash ] = array( 'first_used' => gmdate( 'Y-m-d H:i:s' ), 'content' => $snapshot );
			update_option( self::VERSIONS, array_slice( $versions, -100, null, true ), false );
		}
		return $hash;
	}

	public static function purge() {
		global $wpdb;
		$months = (int) BR_Cookies_Settings::get()['log_retention'];
		$table  = self::table();
		$before = gmdate( 'Y-m-d H:i:s', strtotime( "-{$months} months" ) );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $before ) );
	}

	public static function count() {
		global $wpdb;
		$table = self::table();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
	}

	public static function rows( $limit, $offset = 0, $consent_id = '' ) {
		global $wpdb;
		$table = self::table();
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		if ( '' !== $consent_id ) {
			return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE consent_id = %s ORDER BY id DESC LIMIT %d", strtolower( $consent_id ), $limit ) );
		}
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset ) );
		// phpcs:enable
	}

	public static function deactivate() {
		wp_clear_scheduled_hook( self::CRON );
	}
}
