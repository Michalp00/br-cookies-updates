<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'br_cookies_settings' );
delete_site_transient( 'br_cookies_manifest' );
delete_option( 'br_cookies_db_version' );
delete_option( 'br_cookies_banner_versions' );
wp_clear_scheduled_hook( 'br_cookies_purge' );

global $wpdb;
// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- nazwa tabeli jest stała.
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}br_cookies_consents" );
